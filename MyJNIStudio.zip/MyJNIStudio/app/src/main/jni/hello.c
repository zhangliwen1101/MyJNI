#include<jni.h>

JNIEXPORT jstring JNICALL Java_com_example_administrator_myapplication_MainActivity_getNativeData
  (JNIEnv * env, jclass obj){
    char *str ="Hello, NDK";
    jstring jstr = (*env)->NewStringUTF(env,str);
	return jstr;
}
