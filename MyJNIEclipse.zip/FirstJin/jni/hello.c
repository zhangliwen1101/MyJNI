#include<stdio.h>
#include<stdio.h>
#include "com_example_firstjin_MainActivity.h"

JNIEXPORT void JNICALL Java_com_example_firstjin_MainActivity_printHello
  (JNIEnv * env, jclass jcalss){

	return (*env)->NewStringUTF(env, "Hello from JNI !");
}


