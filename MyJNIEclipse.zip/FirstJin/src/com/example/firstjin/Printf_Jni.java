package com.example.firstjin;

public class Printf_Jni {
	static {
		System.loadLibrary("com_nedu_jni_helloword_printf-jni");
	}

	public native void printHello();
}
